

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Gifford High School</title>


    
        <link rel="stylesheet" href="css/bootstrap.min.css" media="screen" >
        <link rel="stylesheet" href="css/font-awesome.min.css" media="screen" >
        <link rel="stylesheet" href="css/animate-css/animate.min.css" media="screen" >
        <link rel="stylesheet" href="css/lobipanel/lobipanel.min.css" media="screen" >
        <link rel="stylesheet" href="css/toastr/toastr.min.css" media="screen" >
        <link rel="stylesheet" href="css/icheck/skins/line/blue.css" >
        <link rel="stylesheet" href="css/icheck/skins/line/red.css" >
        <link rel="stylesheet" href="css/icheck/skins/line/green.css" >
        <link rel="stylesheet" href="css/main.css" media="screen" >

    <!-- BOOTSTRAP STYLES-->
    <link href="css/bootstrap.css" rel="stylesheet" />
    <!-- FONTAWESOME STYLES-->
    <link href="css/font-awesome.css" rel="stylesheet" />
       <!--CUSTOM BASIC STYLES-->
    <link href="css/basic.css" rel="stylesheet" />
    <!--CUSTOM MAIN STYLES-->
    <link href="css/custom.css" rel="stylesheet" />
    <!-- GOOGLE FONTS-->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
</head>

                <div class="row">
                    <center><div class="col-md-12">
                        <h1 class="page-head-line">GIFFORD HIGH SCHOOL - DASHBOARD</h1>

                    </div></center>
                </div>
                <!-- /. ROW  -->
                
                  <div class="col-md-4">
                        <div class="main-box mb-pink">
                            <a href="students_view.php">
                                <img src="img/Students.png">
                                <h5>Students</h5>
                            </a>
                        </div>
                    </div>
                
                    <div class="col-md-4">
                        <div class="main-box mb-dull">
                            <a href="feescollection_view.php">
                                <img src="img/bank.png">
                                <h5>Collect Fees</h5>
                            </a>
                        </div>
                    </div>
                    
                    
                     <div class="col-md-4">
                        <div class="main-box mb-red">
                            <a href="schoolmoney_view.php">
                                <img src="img/money.png">
                                <h5>Fees Structure</h5>
                            </a>
                        </div>
                    </div>

                    <div class="col-md-4">
                        <div class="main-box mb-pink">
                            <a href="teachers_view.php">
                                <img src="img/teacher.png">
                                <h5>Teachers</h5>
                            </a>
                        </div>
                    </div>

                    <div class="col-md-4">
                        <div class="main-box mb-dull">
                            <a href="classes_view.php">
                                <img src="img/class.png">
                                <h5>Classes</h5>
                            </a>
                        </div>
                    </div>
                  
                  <div class="col-md-4">
                        <div class="main-box mb-red">
                            <a href="notices_view.php">
                                <img src="img/notices.png">
                                <h5>Notices</h5>
                            </a>
                        </div>
                    </div>

                </div>
                <!-- /. ROW  -->

            
            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->

    <div id="footer-sec">
       Gifford High School | Developed By : <a href="http://www.brightappsoft.weebly.com/" target="_blank" style="color: lightblue">Bright AppSoft Designers </a>
    </div>
   
   <script src="js/jquery-1.10.2.js"></script>  
    <!-- BOOTSTRAP SCRIPTS -->
    <script src="js/bootstrap.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="js/jquery.metisMenu.js"></script>
       <!-- CUSTOM SCRIPTS -->
    <script src="js/custom1.js"></script>
    


</body>
</html>
